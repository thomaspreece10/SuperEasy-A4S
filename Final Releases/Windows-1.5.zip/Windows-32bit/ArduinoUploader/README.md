#ArduinoUploader

##What does it do?
On the windows build this handles the automatic upload of code to the Arduino. 
Basically A4S-Helper takes StandardFirmataTemplate and replaces the Baud rate with the one the user specifies in the GUI. It then uses ArduinoUploader to compile and upload this modified code to the specified Arduino.

##Source?
You can find the source here: [https://github.com/thomaspreece10/ArduinoUploader] (https://github.com/thomaspreece10/ArduinoUploader)